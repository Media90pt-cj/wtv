<!doctype html>
<!--[if lt IE 7]> <html class="ie6 oldie"> <![endif]-->
<!--[if IE 7]>    <html class="ie7 oldie"> <![endif]-->
<!--[if IE 8]>    <html class="ie8 oldie"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="">
<!--<![endif]-->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=no" />
<title>itv</title>
<link href="boilerplate.css" rel="stylesheet" type="text/css">
<link href="style.css" rel="stylesheet"  type="text/css">
<link rel="stylesheet" type="text/css" href="/www.itv.net/css/main.css">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="robots" content="noindex, nofollow">
	<meta name="googlebot" content="noindex, nofollow">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="mobile-web-app-capable" content="yes">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
	<meta name="theme-color" content="#FFFFFF"><link rel="shortcut icon" href="/www.itv.net/favicon.png" type="image/x-icon" />
	<link rel="stylesheet" type="text/css" href="style.css">
	 <script type="text/javascript" src="/www.itv.net/js/jquery-1.7.js"></script>

    <link href="https://vjs.zencdn.net/7.7.5/video-js.css" rel="stylesheet" />
<!-- If you'd like to support IE8 (for Video.js versions prior to v7) -->
    <script src="https://vjs.zencdn.net/ie8/1.1.2/videojs-ie8.min.js"></script>


<!-- 
Para obtener más información sobre los comentarios condicionales situados alrededor de las etiquetas html en la parte superior del archivo:
paulirish.com/2008/conditional-stylesheets-vs-css-hacks-answer-neither/
  
Haga lo siguiente si usa su compilación personalizada de modernizr (http://www.modernizr.com/):
* inserte el vínculo del código js aquí
* elimine el vínculo situado debajo para html5shiv
* añada la clase "no-js" a las etiquetas html en la parte superior
* también puede eliminar el vínculo con respond.min.js si ha incluido MQ Polyfill en su compilación de modernizr 
-->
<!--[if lt IE 9]>
<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script src="respond.min.js"></script>
</head>
<body topmargin="0px" leftmargin="0px" rightmargin="0px" bottommargin="0px">

<style>
#video, embed, iframe{ position: absolute; z-index: -1; border:0px; margin-top: 0px; margin-left: 0px;  margin-right:0px; width: 100%; height: 100%; object-fit: cover; }
</style>
<div class="gridContainer clearfix">
  <div id="screen">
<?php


///////////DEF
$dir1="../";
$dabn= 0;
$dvb = "../DVB/DVB";


///////////MOTOR.DB
  $file = fopen($dvb, "r") or die("Unable to DB file!");
	$files = fread($file,filesize($dvb));
	$files1 = explode(']',$files);			
    #$post=substr($pub[5], 0, 40);
	$j = count($files1,0);
    	$i = 0; 
    	$k= $i;
      $dabn= $_GET['s'];


/////////API

  if(!empty($_GET['play'])){
  
    print'<iframe width="100%" height="100%" src="?stby=1" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture; allowfullscreen"  name="screen" style="position:fixed;background-color:black; width:100%; height:100%; border:none; margin-top:0px;  margin-left:0px; margin-bottom:0px; padding: 0px; display:block;" frameborder="0" webkitallowfullscreen="true" mozallowfullscreen="true" allowfullscreen></iframe>
    ';
    print'<!--img src="/www.itv.net/stream/IOD/dvb/'.$_GET['play'].'.png" style="margin-top:2%;margin-left:2%;float:left;position:fixed;color:white;max-height:12%;"-->';
    print'<a href="#">=</a>';

   # print'<div id="sidebar" style="max-width:40%;max-height:90%;position:fixed;">
    
  
 
  }
  if(!empty($_GET['stby'])){
    echo'<center><h1>itv.DVB</h1>Digital Video Broadcast
    </center>';
  }
  elseif(!empty($_GET['s'])){

    $myfile = fopen($dvb, "r") or die("Unable to open file!");
     $files = fread($myfile,filesize($dvb));
     $files1 = explode(']',$files);		
     $pub = explode('‖',$files1[$dabn]);

            if($pub[1]==''){
              print'
              <center><h2>erro 404 - Nao ha mais publicacoes</h2>
            <a href="?play=1">regresse a pagina principal</a>
              ';
            }
           elseif($pub[0]=='1'){
            echo'<img src="/www.itv.net/stream/IOD/dvb/'.$_GET['ch'].'.png" style="margin-top:2%;margin-left:2%;float:left;position:fixed;color:white;max-height:12%;">';
            echo'<iframe src="../DVB/?s='.$_GET['s'].'&ch='.$_GET['ch'].'" frameborder="0" width=100% height="100%"></iframe>
            
            ';
           }
           elseif($pub[0]=='2'){
            echo'<img src="/www.itv.net/stream/IOD/dvb/'.$_GET['ch'].'.png" style="margin-top:2%;margin-left:2%;float:left;position:fixed;color:white;max-height:12%;">';
            echo'<iframe src="'.$_GET['l'].'" width="854" height="480"  frameBorder="0" frameborder="0" scrolling="no" sandbox="allow-popups allow-scripts allow-same-origin" webkitallowfullscreen mozallowfullscreen allowfullscreen seamless="seamless" allowFullScreen></iframe>
            ';
          }
            else{
    echo'
    <video autoplay="true" stretch="true" loop="true" controls="true" webkitallowfullscreen="true" mozallowfullscreen="true" allowfullscreen style="width:100%; height:100%;z-index:-0;"
    id="my-video"
    class="video-js" 
    preload="auto"
    width="100%"
    height="100%"
    poster="/www.itv.net/stream/IOD/dvb/'.$pub[1].'.png"
    data-setup="{}"
  >
          <tv src="'. $pub[5].'"></tv>
          <source src="'. $pub[5].'" type="application/x-mpegurl" >
          <source src="'. $pub[5].'" type="application/x-mpegurl" >
          
          
          
    <p class="vjs-no-js">
      To view this video please enable JavaScript, and consider upgrading to a
      web browser that
      <a href="https://videojs.com/html5-video-support/" target="_blank"
        >supports HTML5 video</a
      >
    </p>
  </video>

  <script src="https://vjs.zencdn.net/7.7.5/video.js"></script>
    ';

    echo'
<!--span data-player-id="cad9d975-ccae-4757-88a3-a65ebb7419f8" style="height:95%;z-index:-2;" -->
  <script src="//cdn.flowplayer.com/players/ed1cc6dd-bf33-4ec1-94e0-669c3180ce75/7/flowplayer.async.js">
    {
    "token": "",
    "autoplay": true,
    "hls": {
        "native": true
    },
    "src": "'.$pub[5].'",
    "ima": {
        "ads": [
            {
                "time": 0,
                "adTag": "https://pubads.g.doubleclick.net/gampad/ads?sz=640x480&iu=/124319096/external/single_ad_samples&ciu_szs=300x250&impl=s&gdfp_req=1&env=vp&output=vast&unviewed_position_start=1&cust_params=deployment%3Ddevsite%26sample_ct%3Dskippablelinear&correlator="
            }
        ]
    },
    "subtitles": {
        "tracks": [
            {
                "src": "https://flowplayer.com/demos/configuration-builder/sample-en.vtt",
                "label": "English",
                "is_default": true
            },
            {
                "src": "https://flowplayer.com/demos/configuration-builder/sample-pt.vtt",
                "label": "Portuguese"
            }
        ]
    },
    "plugins": [
        "ads",
        "subtitles",
        "qsel",
        "keyboard",
        "chromecast",
        "airplay"
    ]
}
  </script> 
</span>

';
  }
  }
  else{
   
    print'<center><ul style="max-height:900px;max-width:150px; margin-top:0px;margin-bottom:0px;overflow-y:auto;">';
 
    

echo'</ul></center>';
  }
?>
  </div>
  <div id="header"> <a href="#menu">=</a></div>

  
    <?php
     if(!empty($_GET['play'])){
    echo'<div id="sidebar" width="width:120px;height:80%">
    <h1 style="margin-top:0px;margin-bottom:0px;"><span style="color:teal;">i</span>tv<br> </h1>
    <a href="index.php?home=1">home</a>/
    <a href="?play=1" title="Video On Demand">DVB</a>
    <!--a href="?play='.$_GET['play'].' title="Video On Demand">'.$_GET['play'].'</a-->
    
    <hr style="margin-top:0px;margin-bottom:0px;">
    ';
    echo '<sidebar style="width:150px;position:fixed;height:70%;overflow:auto;">
    <ul style="width:150px;">';
  
 
   	for ($i = 0; $i <$j; $i++){
    	$pub = explode('‖',$files1[$i]);
	    #$post=substr($pub[5], 0, 40);
	    if($pub[1] == $_GET['dvb']){


	    for($i=1; $i < $j; $i++){
	    	$pub = explode('‖',$files1[$i]);
		    echo'<li style="margin-left:-30px;width:120px;"><a href="?s='.$i.'&ch='.$pub[1].'&l='.$pub[5].'" target="screen"><img src="/www.itv.net/stream/IOD/dvb/'.$pub[1].'.png" width="120px"alt="'.$pub[1].'" title="'.$pub[1].'"></a>';

      }
     }
    else{}
   
    }
}
else{}
 
    echo'</ul>
    </sidebar>	
    </div>
    </div>
  ';
/*
  else{
print'<a href="?home=1">Back to DVB</a>';

  }
  */
  ?>	






    
  
  
  <!--div id="footer">Este es el contenido de la etiqueta Div de diseño "footer"</div-->
</div>
</body>
</html>
